import RedSportShoes from '../images/domino-164_6wVEHfI-unsplash.jpg';
import Pens from '../images/faris-mohammed-PQinRWK1TgU-unsplash.jpg';
import Iphonex from '../images/francesco-1bBCtUAUMFI-unsplash.jpg';
import BoldPens from '../images/girl-with-red-hat-oJG9HOVKGMs-unsplash.jpg';
import Iphone7 from '../images/hardik-sharma-CrPAvN29Nhs-unsplash.jpg';
import ColoredPen from '../images/kelly-sikkema-_oP5ErcnVXE-unsplash.jpg';
import BookOfnature from '../images/kourosh-qaffari-RrhhzitYizg-unsplash.jpg';
import NikeShoes from '../images/maksim-larin-NOpsC3nWTzY-unsplash.jpg';
import Iphone11 from '../images/omid-armin-B2w4rdIihEo-unsplash.jpg';
import LogitechMouse from '../images/oscar-ivan-esquivel-arteaga-ZtxED1cpB1E-unsplash (1).jpg';
import SimpleMouse from '../images/pascal-m-4PchFKrUw84-unsplash.jpg';
import SneakerShoes from '../images/paul-gaudriault-a-QH9MAAVNI-unsplash.jpg';
import GamingMouse from '../images/rebekah-yip-wMT0oiL5XjA-unsplash.jpg';
import ZebronicMouse from '../images/ryan-putra-j4PqlNVZ4Bc-unsplash.jpg';
import Dogalapan from '../images/sincerely-media-nGrfKmtwv24-unsplash.jpg';
import DiaryBook from '../images/studio-media-9DaOYUYnOls-unsplash.jpg';

export const data = [
	{
		id: 1,
		image: RedSportShoes,
		category: 'shoes',
		name: 'red sports shoe',
	},
	{
		id: 2,
		image: Pens,
		category: 'pens',
		name: 'pens',
	},
	{
		id: 3,
		image: Iphonex,
		category: 'mobiles',
		name: 'iphone x - apple',
	},
	{
		id: 4,
		image: BoldPens,
		category: 'pens',
		name: 'bold pens',
	},
	{
		id: 5,
		image: Iphone7,
		category: 'mobiles',
		name: 'iphone 7 - apple',
	},
	{
		id: 6,
		image: ColoredPen,
		category: 'pens',
		name: 'colored pens',
	},
	{
		id: 7,
		image: BookOfnature,
		category: 'books',
		name: 'book of nature',
	},
	{
		id: 8,
		image: NikeShoes,
		category: 'shoes',
		name: 'nike shoes',
	},
	{
		id: 9,
		image: Iphone11,
		category: 'mobiles',
		name: 'iphone 11 - apple',
	},
	{
		id: 10,
		image: LogitechMouse,
		category: 'mouse',
		name: 'logitech mouse',
	},
	{
		id: 11,
		image: SimpleMouse,
		category: 'mouse',
		name: 'simple mouse',
	},
	{
		id: 12,
		image: SneakerShoes,
		category: 'shoes',
		name: 'sneaker shoes',
	},
	{
		id: 13,
		image: GamingMouse,
		category: 'mouse',
		name: 'gaming mouse',
	},
	{
		id: 14,
		image: ZebronicMouse,
		category: 'mouse',
		name: 'zebronic mouse',
	},
	{
		id: 15,
		image: Dogalapan,
		category: 'book',
		name: 'doglapan by ashneer grover',
	},
	{
		id: 16,
		image: DiaryBook,
		category: 'book',
		name: 'diary book',
	},
];
